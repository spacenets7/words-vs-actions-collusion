# Reproducibility sources

This is a local candidate release, not a public upload. Contains our sources only. The upstream checkout is not redistributed: clone https://github.com/Jerick-1380/LLM-Trust-Breaking into pilot/repos/LLM-Trust-Breaking and check out fd11aca351e52c65c929e1a7d46d9f087f237adf if upstream component tests are needed. Its licensing must be reviewed before redistribution.

The original frozen manifest includes local-only development evidence and historical candidate files omitted from this sanitized bundle, so it is a provenance record, not a standalone self-contained archive verification command. bundle-manifest.json records every included file. data/public-trajectories.jsonl and data/oracle-labels.jsonl separate public observations from automatic oracle outcomes; monitor-evidence-and-outputs.jsonl stores exact views and outputs. All labels are provisional pending independent human review.

The full private local workspace retains frozen/development.json and all exact model calls. There, python -m pilot.automate finish regenerates the report with no API calls, and python -m pilot.cli verify-freeze verifies the full original freeze. The automated execution wrapper is separate from the immutable experimental source manifest. Do not launch held-out generation again to reproduce tables; replay saved data with replay.py in the bundle root.

Existing paper code/models are preexisting work. This project implements the new controller, labels, monitor views, Modal runner, metrics and reporting. Do not imply AI-generated checks are independent human annotation.

The requirement-led report source is paper_structure.py. Rebuilding its equations requires Cambria Math on Windows or DejaVu Serif with mathematical glyphs on Linux; no font dependency is needed for offline metrics replay. verify_presentation.py runs full-workspace equation checks against the retained oracle records; it makes no model calls.
