# Track 2.2 judge reproducibility package

Read report.pdf first. This is the current Apart-template manuscript, not the
historical expanded report in the original local bundle. Dataset bytes, model
scores, outcome labels, thresholds and analysis code are unchanged.

Python 3.12 on a CPU:
  python -m pip install -r requirements.txt
  python verify.py
  python replay.py

The first check uses only the Python standard library. Full replay can take
several minutes: it recomputes 5000 whole-family bootstrap draws for both targets
and paired comparisons and requires exact equality with metrics.json. No model,
API key, Modal login, GPU or Docker is needed. The reference environment is
Windows/Python 3.12 with the pinned numerical package versions.

Data contain 12 development and 48 held-out episodes with 240 monitor records.
Read data/DATA_CARD.md before interpreting the operational automatic outcomes.
Private plans/messages and generation journals are absent. Oracle labels are
evaluation-only and must never be supplied as monitor evidence.

bundle-manifest.json verifies this archive's payload. The original complete
freeze manifest is retained in provenance/ for provenance only; this small
analysis archive omits complete-workspace development evidence/candidates.
Use the full GitHub checkout for the complete freeze and 23 component tests:
https://github.com/spacenets7/words-vs-actions-collusion
