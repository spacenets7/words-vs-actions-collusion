import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
manifest=json.loads((root/'bundle-manifest.json').read_text())
for name,expected in manifest.items():
 p=(root/name).resolve()
 assert p.is_relative_to(root),name
 assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==expected,name
read=lambda name:[json.loads(s) for s in (root/name).read_text().splitlines() if s]
assert len(read('data/public-trajectories.jsonl'))==60
assert len(read('data/monitor-evidence-and-outputs.jsonl'))==240
print('Bundle hashes verified: 60 episodes, 240 monitor records. No model/API calls.')
